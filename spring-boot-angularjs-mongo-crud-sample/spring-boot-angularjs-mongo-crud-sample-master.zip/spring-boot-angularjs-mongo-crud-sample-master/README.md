spring-boot-angularjs-mongo-crud-sample
[![Build Status](https://api.travis-ci.org/lennonjesus/spring-boot-angularjs-mongo-crud-sample.svg)](https://travis-ci.org/lennonjesus/spring-boot-angularjs-mongo-crud-sample)

Projeto de estudos com SpringBoot, AngularJS e MongoDB.
